import unittest, tempfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
class ReplyParsing(unittest.TestCase):
 def test_quoted_optout_does_not_change_new_reply(self):
  reply='I am interested. Please send details.\n\nOn Sat, 21 Nov 2026 03:11:42 -0800, sender wrote:\n> To opt out, reply opt out.\n'
  self.assertEqual(app.newest_reply(reply),'I am interested. Please send details.')
  with tempfile.TemporaryDirectory() as d:
   app.DB=Path(d)/'test.db';c=app.conn();c.execute("INSERT INTO leads(name,username,profile_url,email,status,reply_text) VALUES('Test','test','https://www.instagram.com/test/','test@example.com','Replied',?)",(reply,));c.commit();app.classify(c,1,True);self.assertEqual(app.lead(c,1)['status'],'Interested');c.close()
 def test_real_optout_is_not_removed(self):
  self.assertEqual(app.newest_reply('Please opt out.\n\n> old text'),'Please opt out.')
if __name__=='__main__':unittest.main()
