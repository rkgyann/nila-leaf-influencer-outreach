import base64, datetime as dt, email, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));import app
class Call:
 def __init__(self,fn):self.fn=fn
 def execute(self):return self.fn()
class FakeGmail:
 def __init__(self):self.items=[];self.counter=0
 def users(self):return self
 def messages(self):return self
 def threads(self):return self
 def get(self,**kwargs):return Call(lambda:{'messages':list(self.items)})
 def send(self,**kwargs):
  def dispatch():
   self.counter+=1;body=kwargs['body'];raw=base64.urlsafe_b64decode(body['raw']);msg=email.message_from_bytes(raw)
   self.items.append({'id':f'm{self.counter}','payload':{'headers':[{'name':'From','value':'sender@sample.test'},{'name':'Message-ID','value':f'<m{self.counter}@sample.test>'}]},'labelIds':['SENT']})
   return {'id':f'm{self.counter}','threadId':'thread1'}
  return Call(dispatch)
 def incoming(self,text):
  encoded=base64.urlsafe_b64encode(text.encode()).decode().rstrip('=')
  self.items.append({'id':'incoming1','payload':{'mimeType':'text/plain','body':{'data':encoded},'headers':[{'name':'From','value':'creator@sample.test'},{'name':'Message-ID','value':'<r1@sample.test>'}]},'labelIds':['INBOX']})
class FullPipeline(unittest.TestCase):
 def test_approved_send_schedule_reply_blocks_second(self):
  with tempfile.TemporaryDirectory() as folder:
   app.DB=Path(folder)/'case.db';c=app.conn();clock=[dt.datetime(2026,1,1,tzinfo=dt.timezone.utc)];fake=FakeGmail()
   c.execute("INSERT INTO leads(name,username,profile_url,email,niche,status) VALUES('Test','test','https://www.instagram.com/test/','creator@sample.test','skincare','Email Available')");c.commit()
   with patch.object(app,'now',side_effect=lambda:clock[0]),patch.object(app,'google',return_value=(fake,'sender@sample.test')),patch('builtins.input',side_effect=['SEND','APPROVE','APPROVE']):
    app.create_draft(c,1,'initial',True);app.send(c,1)
    app.create_draft(c,1,'followup',True);app.queue_followup(c,2,1)
    app.create_draft(c,1,'followup',True);app.queue_followup(c,3,2)
    app.run_scheduled(c);self.assertEqual(fake.counter,1)
    clock[0]+=dt.timedelta(days=3);app.run_scheduled(c);self.assertEqual(fake.counter,2)
    fake.incoming('Please unsubscribe.\n\nOn Sat, 1 Jan 2026, sender wrote:\n> opt out')
    clock[0]+=dt.timedelta(days=5);app.run_scheduled(c)
    self.assertEqual(fake.counter,2);self.assertEqual(app.lead(c,1)['status'],'Opted Out')
    self.assertEqual([r[0] for r in c.execute('SELECT state FROM followup_jobs ORDER BY id')],['sent','cancelled'])
   c.close()
if __name__=='__main__':unittest.main()
