import json, os, unittest
from unittest.mock import patch
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
class Response:
 def __enter__(self): return self
 def __exit__(self,*args): pass
 def read(self,*args): return json.dumps({'message':{'content':'{"score":80,"summary":"Relevant sample"}'}}).encode()
class OllamaTests(unittest.TestCase):
 @patch.dict(os.environ,{'AI_PROVIDER':'ollama','OLLAMA_MODEL':'qwen3:4b'},clear=False)
 @patch('urllib.request.urlopen')
 def test_local_request(self,request):
  request.return_value=Response()
  self.assertEqual(app.claude('Assess a sample')['score'],80)
  req=request.call_args.args[0]
  self.assertEqual(req.full_url,'http://127.0.0.1:11434/api/chat')
  self.assertEqual(json.loads(req.data)['format'],'json')
 @patch.dict(os.environ,{'AI_PROVIDER':'invalid'},clear=False)
 def test_invalid_provider(self):
  with self.assertRaises(ValueError): app.claude('test')
if __name__=='__main__': unittest.main()
