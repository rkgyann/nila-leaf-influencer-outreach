import datetime as dt, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app
class SchedulerTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();app.DB=Path(self.tmp.name)/'db';self.c=app.conn()
  self.c.execute("INSERT INTO leads(name,username,profile_url,niche,email,status,last_sent,thread_id,subject) VALUES ('Test','test','https://www.instagram.com/test/','beauty','test@sample.test','Email Sent',?,'thread','hello')",((app.now()-dt.timedelta(days=4)).isoformat(),));self.c.commit()
  app.create_draft(self.c,1,'followup',True)
 def tearDown(self):self.c.close();self.tmp.cleanup()
 def test_process_reply_once_and_never_send(self):
  self.c.execute("UPDATE leads SET status='Replied',reply_text='I am interested',reply_message_id='message-1' WHERE id=1");self.c.commit()
  with patch.object(app,'send') as send:
   app.process_replies(self.c,mock=True);app.process_replies(self.c,mock=True);send.assert_not_called()
  self.assertEqual(self.c.execute("SELECT COUNT(*) FROM processed_replies").fetchone()[0],1)
  self.assertEqual(self.c.execute("SELECT COUNT(*) FROM drafts WHERE kind='reply'").fetchone()[0],1)
 def test_optout_does_not_generate_reply(self):
  self.c.execute("UPDATE leads SET status='Replied',reply_text='Please unsubscribe',reply_message_id='message-2' WHERE id=1");self.c.commit()
  app.process_replies(self.c,mock=True)
  self.assertEqual(app.lead(self.c,1)['status'],'Opted Out')
  self.assertEqual(self.c.execute("SELECT COUNT(*) FROM drafts WHERE kind='reply'").fetchone()[0],0)
 @patch('builtins.input',return_value='APPROVE')
 def test_schedule_waits_for_due_and_follows_sequence(self,_input):
  app.queue_followup(self.c,1,1)
  with patch.object(app,'sync'),patch.object(app,'send',return_value=True) as send:
   app.run_scheduled(self.c);send.assert_called_once_with(self.c,1,approved=True)
  self.assertEqual(self.c.execute('SELECT state FROM followup_jobs').fetchone()[0],'sent')
 @patch('builtins.input',return_value='APPROVE')
 def test_reply_cancels_queued_message(self,_input):
  app.queue_followup(self.c,1,1)
  self.c.execute("UPDATE leads SET status='Replied' WHERE id=1");self.c.commit()
  with patch.object(app,'sync'),patch.object(app,'send') as send:app.run_scheduled(self.c);send.assert_not_called()
  self.assertEqual(self.c.execute('SELECT state FROM followup_jobs').fetchone()[0],'cancelled')
 @patch('builtins.input',return_value='APPROVE')
 def test_uncertain_send_blocks_retry(self,_input):
  app.queue_followup(self.c,1,1)
  with patch.object(app,'sync'),patch.object(app,'send',side_effect=RuntimeError('connection lost')):
   app.run_scheduled(self.c)
  self.assertEqual(self.c.execute('SELECT state FROM followup_jobs').fetchone()[0],'blocked')
if __name__=='__main__':unittest.main()
