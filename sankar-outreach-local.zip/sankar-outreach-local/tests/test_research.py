import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));import app
class Response:
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def read(self,*args):return json.dumps({'results':[{'url':'https://www.instagram.com/creator_a/','title':'Creator A','content':'32.5K followers skincare'},{'url':'https://www.instagram.com/reel/abc','title':'post','content':'irrelevant'}]}).encode()
class ResearchTests(unittest.TestCase):
 def test_profile_url_safety(self):
  self.assertEqual(app.profile_handle('https://www.instagram.com/creator_a/'),'creator_a')
  for u in ['https://www.instagram.com/reel/abc','https://evilinstagram.com/test','http://instagram.com/test','https://www.instagram.com/popular/x']:
   self.assertIsNone(app.profile_handle(u))
 def test_follower_count(self):
  self.assertEqual(app.follower_count('32.5K followers'),32500)
  self.assertIsNone(app.follower_count('32.5K following'))
 def test_business_contact_review_is_required(self):
  with tempfile.TemporaryDirectory() as d:
   app.DB=Path(d)/'test.db';c=app.conn();c.execute("INSERT INTO leads(name,username,profile_url,status) VALUES('Test','creator_a','https://www.instagram.com/creator_a/','New Lead')");c.execute("INSERT INTO research_sources(lead_id,url,title,excerpt,discovered_at) VALUES(1,'https://www.instagram.com/creator_a/','profile','For business collaborations email hello@brand.test','2026-11-21')");c.commit()
   self.assertIn('hello@brand.test',app.contact_candidates(c,1));self.assertIsNone(app.lead(c,1)['email'])
   with patch('builtins.input',return_value='VERIFY'):app.approve_contact(c,1,'hello@brand.test')
   self.assertEqual(app.lead(c,1)['status'],'Email Available');c.close()
 @patch('urllib.request.urlopen')
 def test_discover_dedup_and_no_unverified_email(self,mock):
  mock.return_value=Response()
  with tempfile.TemporaryDirectory() as d:
   app.DB=Path(d)/'test.db';c=app.conn();app.discover(c,'skincare','India',1000,50000,5);app.discover(c,'skincare','India',1000,50000,5)
   self.assertEqual(c.execute('SELECT COUNT(*) FROM leads').fetchone()[0],1)
   lead=app.lead(c,1);self.assertEqual(lead['followers'],32500);self.assertEqual(lead['email'],'');self.assertEqual(lead['status'],'New Lead')
   self.assertEqual(c.execute('SELECT COUNT(*) FROM research_sources').fetchone()[0],1);c.close()
if __name__=='__main__':unittest.main()
