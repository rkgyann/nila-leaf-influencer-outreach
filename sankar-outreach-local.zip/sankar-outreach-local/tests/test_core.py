import csv, datetime as dt, os, tempfile, unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app

class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();app.DB=Path(self.tmp.name)/'test.db';self.c=app.conn()
  self.csv=Path(self.tmp.name)/'leads.csv'
  self.csv.write_text('name,username,profile_url,niche,followers,location,email,notes\nTest Creator,test_demo,https://www.instagram.com/test_demo/,skincare,12000,India,test@example.com,skincare routines\n')
  app.import_csv(self.c,self.csv)
 def tearDown(self): self.c.close();self.tmp.cleanup()
 def test_import_duplicate_and_filter(self):
  app.import_csv(self.c,self.csv);self.assertEqual(self.c.execute('SELECT count(*) FROM leads').fetchone()[0],1)
  app.analyze(self.c,1,True);self.assertEqual(app.lead(self.c,1)['score'],85)
 def test_draft_and_optout(self):
  app.create_draft(self.c,1,'initial',True)
  self.assertIn('opt out',self.c.execute('select body from drafts').fetchone()[0])
  self.c.execute("UPDATE leads SET reply_text='Please unsubscribe',status='Replied' WHERE id=1");self.c.commit()
  app.classify(self.c,1,True);self.assertEqual(app.lead(self.c,1)['status'],'Opted Out')
  with self.assertRaises(ValueError):app.create_draft(self.c,1,'followup',True)
 def test_due_and_second_followup(self):
  old=(app.now()-dt.timedelta(days=4)).isoformat();self.c.execute("UPDATE leads SET status='Email Sent',last_sent=? WHERE id=1",(old,));self.c.commit()
  app.due(self.c);self.assertEqual(app.lead(self.c,1)['status'],'Follow-up Due')
 def test_bad_email(self):
  self.csv.write_text('name,username,profile_url,niche,followers,location,email,notes\nA,a,https://www.instagram.com/a/,beauty,0,India,invalid,test\n')
  with self.assertRaises(ValueError):app.import_csv(self.c,self.csv)
 def test_sync_stops_followup_before_analysis(self):
  class Req:
   def execute(self):return {'messages':[{'id':'reply1','labelIds':['INBOX'],'snippet':'Please unsubscribe','payload':{'headers':[{'name':'From','value':'test@example.com'},{'name':'Message-ID','value':'<reply1@example.com>'}]}}]}
  class Threads:
   def get(self,**kwargs):return Req()
  class Users:
   def threads(self):return Threads()
  class Service:
   def users(self):return Users()
  self.c.execute("UPDATE leads SET thread_id='t1',status='Email Sent' WHERE id=1");self.c.commit()
  self.assertTrue(app.sync_one(self.c,app.lead(self.c,1),Service(),'sender@example.com'))
  self.assertEqual(app.lead(self.c,1)['status'],'Replied')
  with self.assertRaises(ValueError):app.create_draft(self.c,1,'followup',True)
  self.assertFalse(app.sync_one(self.c,app.lead(self.c,1),Service(),'sender@example.com'))
if __name__=='__main__':unittest.main()
