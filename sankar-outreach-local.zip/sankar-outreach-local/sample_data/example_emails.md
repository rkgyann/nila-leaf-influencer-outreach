# Fictional examples for review only

## Initial
Subject: Nila Leaf collaboration idea

Hi Asha,

I'm reaching out from Nila Leaf, a fictional sustainable skincare brand exploring refillable packaging. Your skincare and sustainable living content is relevant to our campaign. Would you be open to a short conversation about a possible collaboration?

Best,
Nila Leaf demo team

To opt out of future messages, reply "opt out".

## Follow-up
Subject: Re: Nila Leaf collaboration idea

Hi Asha,

I'm following up on my earlier note about a possible Nila Leaf collaboration. Would you be open to discussing it, or is there a better contact for partnerships?

Best,
Nila Leaf demo team

To opt out of future messages, reply "opt out".

## Reply draft (example; not claimed to be AI-generated)
Subject: Re: Nila Leaf collaboration idea

Hi Asha,

Thanks for your interest! Could you share your media kit and collaboration rates? We can review them and discuss the next steps.

Best,
Nila Leaf demo team

To opt out of future messages, reply "opt out".
